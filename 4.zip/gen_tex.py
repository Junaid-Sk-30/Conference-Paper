import os

tex_code = r"""\documentclass{article}
\usepackage{microtype}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{hyperref}
\usepackage{amsmath,amssymb,mathtools,amsthm}
\usepackage[capitalize,noabbrev]{cleveref}
\usepackage[a4paper,margin=0.75in]{geometry}
\usepackage[round,authoryear]{natbib}
\usepackage{caption}

\renewcommand{\topfraction}{0.95}
\renewcommand{\bottomfraction}{0.95}
\renewcommand{\textfraction}{0.05}
\renewcommand{\floatpagefraction}{0.85}
\renewcommand{\dbltopfraction}{0.95}
\renewcommand{\dblfloatpagefraction}{0.85}

\renewcommand{\thesection}{\Roman{section}}
\renewcommand{\thesubsection}{\Roman{section}.\arabic{subsection}}

\newcommand{\icmltitle}[1]{\centering\Large\bfseries #1\par\vspace{1.2em}}
\newcommand{\icmlkeywords}[1]{\vspace{0.5em}\noindent\textbf{Keywords:} #1\par}

\begin{document}
\twocolumn[
\icmltitle{Causal Graph Regularization for Multi-Asset Return Forecasting:\\A Reproducibility-Focused Evaluation}
\begin{center}
    \textbf{Shaik Junaid}$^1$, \textbf{Sk. Valijan}$^1$, and \textbf{Dr. Nadiminti Nagamani}$^2$\\
    \vspace{0.3em}
    $^1$Department of Data Science, VIT-AP University, Amaravati, Andhra Pradesh, India\\
    $^2$Assistant Professor Grade 2, School of Advanced Science, VIT-AP University, Amaravati, Andhra Pradesh, India\\
    \texttt{*shaik.junaid@vitap.ac.in}
\end{center}
\vspace{0.5em}
\icmlkeywords{Financial forecasting; causal discovery; multivariate time series; inverted Transformer; transaction costs; Kolmogorov-Arnold Networks; RBF-KAN.}
\vskip 0.25in
]

\begin{abstract}
We evaluate graph-regularized inverted Transformers for next-day returns on a 30-equity U.S. panel. The primary benchmark compares dense attention, correlation and PCMCI+ masks, soft causal routing, and a Radial Basis Function Kolmogorov-Arnold Network (RBF-KAN) prediction head against historical-mean, persistence, and VAR baselines. The later generated 30-stock tables report negative out-of-sample $R^2$ for every neural model (from $-2.35\%$ to $-4.54\%$). Soft causal routing with a linear head has the highest reported gross Sharpe ($1.455 \pm 0.177$), but its 5-basis-point net Sharpe is negative ($-0.321 \pm 0.145$). The KAN-head model labelled TKAN in the code has lower turnover (1.32) but weaker gross and net Sharpe. Separate 5-epoch mini-ablations are exploratory and are not pooled with the three-seed primary benchmark. The training loader shuffles examples while the loss penalizes adjacent weights within each batch, so that term does not measure turnover between consecutive dates. Results are descriptive and do not establish profitable net alpha or causal identification.
\end{abstract}

\section{Introduction}
Financial markets connect assets through intricate, non-stationary networks of information flow, liquidity sharing, and systemic contagion. In volatile regimes, cross-asset dependencies shift abruptly: relationships dormant during calm periods suddenly transmit shocks across sectors. Modeling these multivariate dependencies is a primary focus of financial machine learning. However, applying modern deep sequence architectures to daily equity returns faces a fundamental barrier: the extreme low signal-to-noise ratio (SNR) of financial markets.

Recent empirical prototypes combining Graph Convolutional Networks (GCNs) and Recurrent Units (GRUs) frequently suffer from severe failure modes. When subjected to rigorous out-of-sample testing, unconstrained neural networks memorize sample-specific noise, reporting negative coefficients of determination ($R^2 < 0$) and nominal directional accuracy (e.g., $53\text{--}55\%$) that merely reflects the sample proportion of positive return days during a secular bull market. Standard Vector Autoregression (VAR) benchmarks consistently select lag order zero under the Bayesian Information Criterion (BIC), demonstrating that linear autoregressive dynamics are indistinguishable from an unconditional historical mean.

To overcome these failure modes, we argue that deep learning models in quantitative finance require principled inductive biases. Rather than permitting unconstrained all-to-all attention across all assets, cross-asset attention can be regularized with rolling graph estimates, while graph discovery remains sensitive to model and testing choices.

This paper evaluates a graph-regularized inverted-Transformer framework. We make four primary contributions:
\begin{enumerate}
    \item \textbf{Soft Causal Attention Routing}: We introduce a continuous, learnable gating mechanism that modulates cross-asset attention using lagged PCMCI+ graph inputs. The continuous gate keeps all attention pairs available, but its economic effect is evaluated empirically rather than assumed.
    \item \textbf{Reproducibility Audit}: We compare the supplied summary tables and implementation excerpts, distinguishing archived reported metrics from methodology claims that are not confirmed by the checked code.
    \item \textbf{TKAN / RBF-KAN Prediction Heads}: We compare a linear head with the Gaussian radial-basis KAN-style head labelled TKAN by the supplied code; we evaluate its formulation as an RBF-KAN layer \citep{liu2024kan} and do not assume it improves generalization over simpler baselines.
    \item \textbf{Rigorous Econometric Benchmarking \& Friction Reality}: We evaluate on a 30-asset panel across 10 years (2016--2025) under a chronological evaluation protocol described in the experiment files, comparing against the Constant Mean Predictor, Naive Persistence, and VAR. We report both gross cross-sectional signal ranking and net Sharpe ratios under institutional fees (5 and 10 bps), documenting how turnover decay affects daily financial machine learning strategies.
\end{enumerate}

Throughout this work, we maintain that edges discovered by PCMCI+ represent \textit{directed predictive precedence conditional on the observed conditioning set}, rather than invariant physical causal mechanisms.

\section{Related Work}
\subsection{Causal Discovery in Multi-Asset Time Series}
Bivariate Granger causality tests evaluate whether past observations of series $j$ reduce forecast variance for series $i$ relative to $i$'s own history \citep{granger1969}. However, bivariate tests are profoundly susceptible to omitted variable bias and spurious contemporaneous correlation in multi-asset systems. Constraint-based causal discovery, exemplified by the PCMCI and PCMCI+ algorithms \citep{runge2020}, resolves these limitations by executing iterative conditional independence tests (via partial correlation) while conditioning on minimal conditioning sets. This provides a structured conditional-independence procedure for autocorrelated panels; its conclusions depend on the selected test, conditioning set, and multiple-testing treatment.

\subsection{Inverted Transformers for Multivariate Forecasting}
Conventional Transformer architectures tokenize temporal slices, processing multivariate features as channels within each time token. Recent work demonstrates that the Inverted Transformer (\textit{iTransformer}) radically improves multi-series modeling by inverting the tokenization dimension: the entire temporal lookback sequence of an individual variable is embedded as an individual token, while self-attention is applied cross-sectionally across variables \citep{liu2024itransformer}. This aligns naturally with financial networks, where self-attention across tokens directly represents cross-asset spatial interaction.

\subsection{KAN-Style Prediction Heads}
Kolmogorov--Arnold Networks replace fixed node activations with learnable univariate functions on edges \citep{kolmogorov1957,liu2024kan}; subsequent Temporal KAN (TKAN) work combines KAN layers with recurrent memory cells and multi-frequency gating mechanisms \citep{genet2024tkan}. The supplied model instead uses a feed-forward KAN-style Radial Basis Function (RBF) output layer within an inverted Transformer architecture. Because the inverted Transformer already projects the full temporal lookback window into token space, the prediction head operates as an RBF-KAN layer \citep{liu2024kan}, which we distinguish from the recurrent TKAN architecture of \citet{genet2024tkan}.

\section{Proposed Methodology}
\subsection{Data Representation and Chronological Split}
The supplied adjusted-price archive contains 2,513 daily rows from 2016-01-04 through 2025-12-30 for 30 U.S. equities: AAPL, MSFT, GOOGL, AMZN, NVDA, META, JPM, BAC, GS, MS, WFC, BLK, XOM, CVX, COP, SLB, JNJ, UNH, PFE, ABBV, MRK, PG, KO, PEP, COST, WMT, CAT, HON, BA, and UNP. Prices are forward-filled, log returns are computed, and each asset is represented by its daily return, 20-day rolling standard deviation (volatility), and 20-day rolling mean (momentum). The target is the next trading day's return vector $\mathbf{y}_{t+1} \in \mathbb{R}^N$ obtained via a 1-day backward shift (\texttt{.shift(-1)}). The supplied archive attributes the adjusted prices to Yahoo Finance; retrieval metadata and point-in-time constituent selection are not provided.

\begin{figure}[t]
\centering
\includegraphics[width=\columnwidth]{figures/figure1_network_density_timeline.png}
\caption{Archived rolling graph-density series. The plot is descriptive and does not establish causal identification or correction for multiple testing.}
\label{fig:fig1_density}
\end{figure}

The experiment code fits feature and target standardizers on training data only. Its sequence builder produces 2,472 examples, then applies chronological 70/15/15 cut points, purging 20 lookback observations before validation and purging 20 observations plus a 5-day embargo before test. The reported partitions are 1,730 training days (2016-03-02 to 2023-01-12, $70.0\%$), 351 validation days (2023-02-13 to 2024-07-08, $14.2\%$), and 346 test days (2024-08-13 to 2025-12-29, $14.0\%$); the remaining 45 examples are purge/embargo intervals (20 days purged between train and validation from 2023-01-13 to 2023-02-10, and 25 days purged/embargoed between validation and test from 2024-07-09 to 2024-08-12). This produces $346 \times 30 = 10,380$ asset-day forecasts per seed. The stand-alone October 14 CSV exports are not consistent with the later generated results used in the primary tables.

\subsection{Rolling PCMCI+ Graphs}
The 30-stock runner loads precomputed graphs from \texttt{rolling\_graphs\_30.pkl} and assigns each sample the latest graph date not later than that sample. The supplied manuscript describes these graphs as PCMCI+ estimates over 252-day windows, advanced by 21 days, with maximum lag 2 and a 0.05 edge threshold. The graph-generation script is not among the supplied experiment scripts, so these settings cannot be independently checked from the runner itself. We therefore interpret edges as thresholded conditional predictive associations, not identified causal effects or FDR-controlled discoveries. The macro-conditioned/FDR graph workflow is a separate 10-stock experiment described with the walk-forward results below.

The binary adjacency used as an attention prior can be written as:
\begin{equation}
C_t[i, j] = \begin{cases}
1, & \exists \tau \in \{1, 2\} : p_{j \to i, \tau} < 0.05, \\
0, & \text{otherwise}.
\end{cases}
\end{equation}
Self-links are retained ($C_t[i, i] = 1$) so each asset can attend to its own history.

\subsection{Soft Causal Inverted Transformer}
Given lookback $L = 20$ and $F = 3$ features, each asset's history $\mathbf{X}_i \in \mathbb{R}^{L \times F}$ is projected into embedding space:
\begin{equation}
\mathbf{h}_i^{(0)} = \mathbf{W}_e \operatorname{vec}(\mathbf{X}_i) + \mathbf{b}_e \in \mathbb{R}^{d_{\mathrm{model}}}.
\end{equation}
Across all $N$ tokens $\mathbf{H} \in \mathbb{R}^{N \times d_{\mathrm{model}}}$, multi-head attention computes raw scores $\mathbf{S} = \mathbf{Q}\mathbf{K}^\top / \sqrt{d_k}$. Rather than imposing non-differentiable hard masking ($-\infty$), our soft causal routing layer modulates attention via a learned parameterization:
\begin{equation}
\mathbf{S}_{\mathrm{routed}} = \mathbf{S} \odot \left(1 + \operatorname{ReLU}(\gamma) \cdot \sigma(\alpha \mathbf{C}_t + \beta)\right),
\end{equation}
where $\alpha \in \mathbb{R}^{H}$ and $\beta \in \mathbb{R}^{H}$ are per-head learnable scaling and bias parameters, and $\gamma \in \mathbb{R}$ governs maximum gating intensity. This score rescaling preserves entries for all pairs; because it multiplies signed logits, it does not guarantee that every graph edge receives greater post-softmax attention.

\subsection{KAN-Style Prediction Head (TKAN Label in the Code)}
The supplied implementation's \texttt{KANLinear} adds a SiLU base projection to learned Gaussian radial-basis responses on a five-point grid. It is labelled TKAN in the experiment tables, but this is a KAN-style output layer and does not implement the recurrent temporal architecture described in the original TKAN paper \citep{liu2024kan,genet2024tkan}. We retain TKAN only when reproducing the code's model label:
\begin{equation}
\label{eq:rbf_kan_head}
\widehat{z}_{i, t+1} = \mathbf{W}_{\mathrm{base}} \operatorname{SiLU}(\mathbf{h}_i^{(L)}) + \sum_{g=1}^G \mathbf{W}_{\mathrm{spline}, g} \phi_g(\mathbf{h}_i^{(L)}),
\end{equation}
where $\phi_g(u) = \exp(-((u - \mu_g)/\Delta)^2)$ are Gaussian radial basis functions centered at equidistant grid points $\mu_g \in [-1, 1]$, $\Delta$ denotes basis bandwidth, and $\mathbf{W}_{\mathrm{spline}}$ are trainable combination weights.

\subsection{Cost-Aware Differentiable Portfolio Loss}
To align neural optimization with economic viability, we formulate a hybrid loss function. While standard MSE operates on standardized targets $\mathbf{z}_{t+1}$, the portfolio objective is strictly computed using \textbf{true, unstandardized daily return units} $\mathbf{y}_{t+1}$:
\begin{equation}
\mathcal{L}_{\mathrm{total}} = \mathcal{L}_{\mathrm{MSE}}(\widehat{\mathbf{z}}, \mathbf{z}) + \lambda_{\mathrm{sr}}\mathcal{L}_{\mathrm{Sharpe}}(\mathbf{w}, \mathbf{y}) + \lambda_{\mathrm{to}}\mathcal{L}_{\mathrm{TO}}(\mathbf{w}).
\end{equation}
Predicted standardized returns are mapped to dollar-neutral portfolio weights:
\begin{equation}
w_{i,t} = \frac{\widehat{z}_{i,t} - \bar{z}_t}{\sum_j |\widehat{z}_{j,t} - \bar{z}_t| + \epsilon}, \quad \sum_i w_{i,t} = 0, \quad \sum_i |w_{i,t}| = 1.
\end{equation}
Realized portfolio return is $R_{p,t} = \sum_i w_{i,t} y_{i,t}$. Annualized Sharpe loss and turnover penalty are defined as:
\begin{align}
\mathcal{L}_{\mathrm{Sharpe}} &= -\sqrt{252} \cdot \frac{\mathbb{E}[R_{p,t}]}{\operatorname{Std}(R_{p,t}) + \epsilon}, \\
\mathcal{L}_{\mathrm{TO}} &= \frac{1}{B-1} \sum_{t=2}^B \sum_{i=1}^N |w_{i,t} - w_{i,t-1}|.
\end{align}

The implementation forms training mini-batches with \texttt{shuffle=True}. Consequently, the batch-adjacency term above compares shuffled examples rather than consecutive calendar dates; it should not be interpreted as a faithful temporal turnover penalty in these runs.

\section{Experimental Setup}
\subsection{Training and Reproducibility Settings}
The main 30-stock runner uses three fixed seeds (42, 123, 999), a 20-day lookback, model width 64, four attention heads, feed-forward width 128, and dropout 0.10. It trains with AdamW (learning rate $10^{-3}$, weight decay $10^{-4}$), batch size 32, and up to 20 epochs, selecting the checkpoint with the lowest validation MSE and clipping gradients at norm 10. The code selects CUDA when available and otherwise CPU; the supplied files do not identify a specific GPU/CPU model or pinned software environment. The batch loader shuffles examples.

The later generated results used in Tables 1--2 are in \texttt{data\_artifacts/table1\_reproducible\_forecasting\_metrics.csv} and \texttt{table2\_reproducible\_backtest\_metrics.csv}. They aggregate neural-model metrics across the three seeds as mean $\pm$ standard error. The separate root-level \texttt{benchmark\_metrics\_30stocks.csv} and \texttt{backtest\_metrics\_30stocks.csv} exports are dated earlier and report materially different results; they are treated as superseded exports, not combined with the later outputs.

% Float for Page 4 (Figure 2 + Figure 3) declared on Page 3
\begin{figure*}[t]
\centering
\includegraphics[width=0.92\textwidth,height=1.95in,keepaspectratio]{figures/figure5_soft_causal_routing_and_sharpe.png}
\caption{Additional soft-routing and loss ablation visualization from the archive. It summarizes a separate experimental output; its Sharpe values should not be conflated with Table 2.}
\label{fig:fig2_ablation}
\vskip 0.05in
\includegraphics[width=0.62\textwidth,height=4.3in,keepaspectratio]{figures/figure2_causal_graph_network.png}
\caption{Archived conditional-association graph for a 2020 window. Edges reflect the supplied thresholding procedure and should not be read as identified causal effects.}
\label{fig:fig3_graph}
\end{figure*}

\subsection{Statistical Benchmarks}
We benchmark against established reference models:
\begin{enumerate}
    \item \textbf{Constant Mean Predictor}: Forecasts the historical training mean $\bar{\mathbf{y}}_{\mathrm{train}}$.
    \item \textbf{Naive Persistence}: Forecasts yesterday's return $\mathbf{y}_t$.
    \item \textbf{Vector Autoregression (VAR)}: Unrestricted VAR with BIC lag selection (which selects lag order 0).
    \item \textbf{iTransformer (Dense)}: Unconstrained cross-asset self-attention ($\mathbf{C}_t = \mathbf{0}$).
    \item \textbf{iTransformer (Correlation Mask)}: Masking attention with top 20\% Pearson correlation.
    \item \textbf{iTransformer (PCMCI+ Causal Mask)}: Additive hard masking ($-\infty$) with PCMCI+ graph.
    \item \textbf{Soft Causal iTransformer (Linear Head)}: Soft routing with a standard linear head.
    \item \textbf{Soft Causal TKAN (Proposed Full Model)}: Soft routing, TKAN head (implemented as an RBF-KAN layer; \citealp{liu2024kan}), and cost-aware loss.
\end{enumerate}

\subsection{Evaluation Metrics}
We compute Campbell-Thompson out-of-sample $R^2$:
\begin{equation}
R^2_{\mathrm{OOS}} = 1 - \frac{\sum_{t=1}^T \sum_{i=1}^N (y_{i,t} - \widehat{y}_{i,t})^2}{\sum_{t=1}^T \sum_{i=1}^N (y_{i,t} - \bar{y}_{i,\mathrm{train}})^2}.
\end{equation}
Directional Accuracy (DA) is compared with the empirical positive-return rate. Panel Diebold--Mariano statistics use the supplied implementation's Harvey--Leybourne--Newbold small-sample factor for one-step forecasts; reported $p$-values are arithmetic averages across seeds, not a pooled test \citep{diebold1995,harvey1997}. Dollar-neutral quintile backtests hold six long and six short names, with gross and net Sharpe reported at 0, 5, and 10 bps. Neural rows show mean $\pm$ standard error across seeds.

% Float for Page 5 (Table 1 + Table 2) declared on Page 4
\begin{table*}[t]
\caption{Unified 30-asset statistical forecasting benchmark ($T_{\mathrm{test}} = 346$ trading days, 10,380 predictions across seeds 42, 123, 999). Target benchmark: Historical Training Mean ($\bar{\mathbf{y}}_{\mathrm{train}}$). HLN-adjusted Panel Diebold-Mariano tests evaluated against the Mean Predictor.}
\label{tab:results30}
\vskip 0.05in
\centering
\small
\begin{tabular}{lcccccc}
\toprule
Model Architecture & MAE & RMSE & $R^2_{\mathrm{OOS}}$ (\%) & Dir. Acc. (\%) & Base Rate (\%) & Panel DM Stat ($p$-value) \\
\midrule
Constant Mean Predictor & 0.0120 & 0.0181 & 0.00 & 52.66 & 52.63 & 0.00 (1.000) \\
Vector Autoregression (VAR, BIC=0) & 0.0120 & 0.0181 & -0.00 & 52.66 & 52.63 & 0.00 (1.000) \\
Naive Persistence & 0.0175 & 0.0250 & -90.72 & 50.51 & 52.63 & -10.62 ($<0.001$) \\
\midrule
iTransformer (Dense / No Graph) & $0.0123 \pm 0.0000$ & $0.0183 \pm 0.0000$ & $-2.63\% \pm 0.18\%$ & $50.77\% \pm 0.41\%$ & 52.63 & $-1.87 \pm 0.12$ (0.068) \\
iTransformer (Correlation Mask) & $0.0123 \pm 0.0000$ & $0.0183 \pm 0.0000$ & $-2.90\% \pm 0.17\%$ & $50.88\% \pm 0.25\%$ & 52.63 & $-2.27 \pm 0.12$ (0.027) \\
iTransformer (PCMCI+ Causal Mask) & $0.0122 \pm 0.0000$ & $0.0183 \pm 0.0000$ & $\mathbf{-2.35\% \pm 0.10\%}$ & $50.64\% \pm 0.27\%$ & 52.63 & $-2.02 \pm 0.12$ (0.048) \\
Soft Causal iTransformer (Linear) & $0.0123 \pm 0.0000$ & $0.0184 \pm 0.0000$ & $-3.24\% \pm 0.22\%$ & $50.36\% \pm 0.26\%$ & 52.63 & $-1.92 \pm 0.31$ (0.090) \\
Soft Causal TKAN (Full Proposed) & $0.0124 \pm 0.0000$ & $0.0185 \pm 0.0001$ & $-4.54\% \pm 0.64\%$ & $50.04\% \pm 0.50\%$ & 52.63 & $-3.45 \pm 0.37$ (0.003) \\
\bottomrule
\end{tabular}
\vskip 0.12in
\caption{Reconciled cost-aware dollar-neutral quintile backtest on the 30-asset panel (seeds 42, 123, 999). Daily rebalancing across top 6 long and bottom 6 short equities under institutional transaction frictions.}
\label{tab:backtest30}
\vskip 0.05in
\centering
\small
\begin{tabular}{lccccc}
\toprule
Strategy & Mean Turnover & Gross Sharpe (0 bps) & Net Sharpe (5 bps) & Net Sharpe (10 bps) & Max Drawdown (5 bps) \\
\midrule
Constant Mean Predictor & 0.00 & +0.236 & +0.236 & +0.236 & 10.4\% \\
Vector Autoregression (VAR) & 0.00 & +0.236 & +0.236 & +0.236 & 10.4\% \\
Naive Persistence & 1.55 & +0.541 & -1.325 & -3.192 & 18.6\% \\
\midrule
iTransformer (Dense / No Graph) & 1.35 & $+0.725 \pm 0.504$ & $-0.839 \pm 0.486$ & $-2.401 \pm 0.472$ & 17.6\% \\
iTransformer (Correlation Mask) & 1.43 & $+0.790 \pm 0.193$ & $-0.910 \pm 0.155$ & $-2.605 \pm 0.133$ & 17.0\% \\
iTransformer (PCMCI+ Causal Mask) & 1.44 & $+0.643 \pm 0.138$ & $-1.104 \pm 0.124$ & $-2.852 \pm 0.126$ & 19.4\% \\
Soft Causal iTransformer (Linear) & 1.42 & $\mathbf{+1.455 \pm 0.177}$ & $\mathbf{-0.321 \pm 0.145}$ & $\mathbf{-2.092 \pm 0.134}$ & $\mathbf{14.0\%}$ \\
Soft Causal TKAN (Full Proposed) & \textbf{1.32} & $+0.191 \pm 0.157$ & $-1.403 \pm 0.117$ & $-2.993 \pm 0.089$ & 22.1\% \\
\bottomrule
\end{tabular}
\end{table*}

\section{Results and Discussion}
\subsection{Statistical Forecasting \& Inductive Regularization}
Table 1 summarizes statistical forecasting performance across all models on the 30-stock panel. Both the Constant Mean Predictor and VAR (which selected BIC lag 0) achieve identical metrics ($R^2_{\mathrm{OOS}} = 0\%$, Directional Accuracy $52.66\%$), perfectly tracking the empirical up-day base rate of $52.63\%$. This confirms that simple directional accuracy metrics in financial machine learning are dominated by unconditional equity drift rather than genuine predictive alpha.

Consistent with the low-SNR bounds established in financial econometrics \citep{campbell2008}, all neural architectures exhibit slightly negative $R^2_{\mathrm{OOS}}$ ($-2.35\%$ to $-4.54\%$). The differences between these rows are descriptive and do not by themselves establish a general inductive-regularization effect: the PCMCI+ causal mask achieves the strongest variance control ($-2.35\% \pm 0.10\%$), outperforming dense unconstrained attention ($-2.63\% \pm 0.18\%$) and correlation masking ($-2.90\% \pm 0.17\%$). When non-linear TKAN heads and portfolio objectives are introduced, forecasting $R^2$ shifts slightly to $-4.54\%$ as model capacity prioritizes cross-sectional ranking over point-magnitude prediction.

\subsection{Economic Evaluation \& Transaction Cost Realities}
Table 2 presents the economic evaluation under institutional transaction frictions. Prior to transaction costs, cross-sectional ranking produces notable gross signals. In particular, the Soft Causal iTransformer with linear head generates an annualized Gross Sharpe ratio of $+1.455 \pm 0.177$, substantially outperforming unconstrained dense attention ($+0.725 \pm 0.504$) and hard causal masking ($+0.643 \pm 0.138$). Furthermore, it reduces maximum drawdown under 5 bps fees to 14.0\%.

Daily quintile rebalancing incurs substantial turnover: 1.32 to 1.44 per day. Because the supplied summary does not fully document the turnover convention, we focus on the directly reported fee-adjusted Sharpe metrics. The soft-causal linear model has net Sharpe $-0.321$ at 5 bps and $-2.092$ at 10 bps. The TKAN-labelled model reports turnover of 1.32, the lowest among neural entries, but its net Sharpe is lower than the linear soft-causal model. This does not show that its turnover penalty improves net performance.

% Float for Page 6 (Figure 4 + Figure 5 + Table 3) declared on Page 5
\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth,height=2.05in,keepaspectratio]{figures/figure3_ablation_performance_comparison.png}
\caption{Additional ablation visualization supplied in the archive. These exploratory values are from a separate ablation output and are not substituted for the reconciled main benchmark tables.}
\label{fig:fig4_ablation}
\vskip 0.05in
\includegraphics[width=\textwidth,height=2.45in,keepaspectratio]{figures/figure4_cumulative_backtest_curves.png}
\caption{Archived cumulative portfolio-growth curves after 5 bps costs. Read alongside the summary table: plotted trajectories show strategy dispersion and losses, not consistent net profitability.}
\label{fig:fig5_cumulative}
\vskip 0.08in
\captionof{table}{Exploratory regime-specific evaluation on a 10-stock cross-sector subset; entries are unweighted means across 2020, 2022, and 2024 test periods. The WFO runner uses continuous raw-p-value graph confidence, not the separately stored FDR-pruned graph.}
\label{tab:wfo_regimes}
\vskip 0.05in
\small
\begin{tabular}{lccc}
\toprule
Model & Mean $R^2_{\mathrm{OOS}}$ (\%) & Mean Gross SR & Mean Net SR (5 bps) \\
\midrule
Constant Mean / VAR & 0.00 & +0.185 & +0.185 \\
Dense iTransformer & -2.04 & +0.349 & -0.217 \\
Soft Causal (Linear) & -2.17 & +0.088 & -0.455 \\
Soft Causal TKAN & -4.25 & -0.719 & -1.303 \\
\bottomrule
\end{tabular}
\end{figure*}

\subsection{Multi-Regime Walk-Forward Optimization (WFO)}
A separate regime experiment uses the 10-stock subset AAPL, MSFT, GOOGL, NVDA, JPM, BAC, XOM, JNJ, PG, and CAT, with four macro controls (VIX, TNX, UUP, SPY). The graph script estimates 252-day windows every 63 days with maximum lag 1 and computes both strict BH-FDR-pruned and continuous raw-p-value confidence matrices. The WFO runner specifically feeds the continuous \texttt{pcmci\_cont} matrix to the model; the cross-regime table is therefore not an FDR-pruned result. Tests cover February--December 2020, 2022, and 2024 after regime-specific training/validation intervals. This exploratory 10-stock analysis is separate from the 30-stock benchmark:
\begin{itemize}
    \item \textbf{Regime 1 (2020)}: COVID-19 crash and rapid liquidity injection.
    \item \textbf{Regime 2 (2022)}: Federal Reserve monetary tightening and inflation shock.
    \item \textbf{Regime 3 (2024)}: AI technology expansion and macroeconomic normalization.
\end{itemize}
As documented in Table 3, while unconditional drift drives the historical mean benchmark (yielding Sharpe $+1.234$ in 2020, $-1.782$ in 2022, and $+1.102$ in 2024), dollar-neutral neural strategies isolate idiosyncratic cross-sectional returns. Net Sharpe at 10 bps is negative across all regimes for all daily neural models, underscoring that claims of consistent net daily profitability are incompatible with empirical execution frictions.

% Float for Page 7 (Figure 6) declared on Page 6 (before Section V.4)
\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth,height=2.3in,keepaspectratio]{figures/figure6_multi_regime_wfo_and_macro_topology.png}
\caption{Archived multi-regime and graph visualization. The portfolio panels are supplementary outputs; the topology panel is included as provided and is not evidence of macro-conditioned discovery or FDR control, which are not substantiated by the checked implementation.}
\label{fig:fig6_wfo}
\end{figure*}

\subsection{Exploratory Mini-Ablations}
The three supplied mini-ablation CSVs report short developmental runs and are not three-seed estimates. In the soft-routing mini-ablation, dense, correlation-gated, and soft-routed models report $R^2_{\mathrm{OOS}}$ of $-2.72\%$, $-2.67\%$, and $-2.87\%$, respectively; their 5-bps net Sharpe values are $-0.503$, $-0.265$, and $-0.263$. In the Sharpe-loss mini-ablation, adding the hybrid objective to the soft-routed model changes reported turnover from 1.43 to 1.30 and 5-bps net Sharpe from $-0.263$ to $-0.107$, while $R^2_{\mathrm{OOS}}$ declines from $-2.87\%$ to $-8.76\%$. In the separate head/turnover mini-ablation, the full TKAN-labelled configuration reports turnover 0.95, gross Sharpe $-0.514$, and net Sharpe $-1.427$ at 5 bps ($-2.338$ at 10 bps). These short runs are exploratory, use different configurations from the main benchmark, and do not demonstrate a profitable result. The shuffled-batch issue also limits the interpretation of their turnover penalty.

\subsection{Interpretation}
Our findings offer critical methodological guidance for quantitative machine learning:
\begin{enumerate}
    \item \textbf{Causal Attention as Variance Regularizer}: In ultra-low SNR regimes, unconstrained attention memorizes spurious correlations across non-causally connected pairs. The reported PCMCI+ hard-mask row has the least negative out-of-sample $R^2$ among neural rows; this is a descriptive difference and does not establish a general variance-control effect.
    \item \textbf{Soft Routing vs. Hard Masking}: Discontinuous $-\infty$ masking forces zero attention regardless of operational context, creating gradient dead zones. Soft gating $\mathbf{S} \odot (1 + \operatorname{ReLU}(\gamma)\sigma(\alpha \mathbf{C} + \beta))$ modulates attention smoothly. The strongest gross Sharpe ($+1.455$) is reported for the soft-causal linear variant; net Sharpe remains negative after fees.
    \item \textbf{The Institutional Turnover Hurdle}: The central bottleneck in daily financial machine learning is transaction turnover, not pattern recognition. A model with an impressive gross Sharpe of $+1.45$ is rendered unprofitable by daily rebalancing turnover ($\approx 1.4$). Researchers must report turnover and net metrics transparently rather than relying on frictionless gross evaluations.
\end{enumerate}

\section{Limitations}
Several limitations affect interpretation and reproducibility. The stand-alone October 14 benchmark CSVs conflict with the October 25 generated tables used here; a versioned rerun should reconcile and checksum the outputs. The 30-stock runner consumes a cached graph, but its graph-generation script is absent from the supplied code. The regime analysis is a separate 10-stock experiment and uses continuous raw-p-value confidence, not its available FDR-pruned matrix. Most materially, the mini-batch loader shuffles dates while the turnover loss compares adjacent rows in each batch, so the implemented penalty is not temporal turnover. The KAN-style output head is labelled TKAN but is not the recurrent TKAN architecture. The results cover three seeds, a fixed universe, and simplified fee assumptions; they do not establish external validity or investable net alpha.

\section{Conclusion and Future Work}
This paper reports a reproducibility-focused evaluation of graph-regularized forecasting on the supplied 30-stock panel. The later generated results show negative out-of-sample $R^2$ for all neural models and negative net Sharpe after the stated trading costs. Soft causal routing with a linear head has the highest descriptive gross Sharpe, while the KAN-style head labelled TKAN does not improve the main benchmark. The separate regime and mini-ablation analyses do not overturn that conclusion. A versioned rerun should reconcile the older CSV exports, include graph-generation code, and compute any turnover penalty on chronologically ordered observations before claims about economic benefit are made.

\section*{Declarations}
\textbf{Funding}: The supplied manuscript states that no external funding was received.\\
\textbf{Conflicts of interest}: The supplied manuscript states that the authors declare no conflicts of interest.\\
\textbf{Ethics}: Not applicable; the reported work uses financial market data and no human participants.\\
\textbf{AI use}: Generative AI assistance was used for code inspection and preparation/verification of manuscript text and LaTeX. The authors should confirm this wording and disclose use according to the target venue's policy.

\section*{Data and Code Availability}
The supplied package includes the adjusted-price and macro-proxy CSVs, experiment scripts, cached graph files, result CSVs, and six figure files. The 30-stock run depends on the precomputed \texttt{rolling\_graphs\_30.pkl}; the supplied runner does not regenerate it. No stable public repository URL or archive DOI was provided. Before submission, publish the package and replace this statement with a persistent access link and exact retrieval/software metadata.

\begin{thebibliography}{10}
\bibitem[Campbell \& Thompson(2008)]{campbell2008}
Campbell, J.~Y., \& Thompson, S.~B. (2008). Predicting the equity premium out of sample: Can anything beat the historical average? \textit{The Review of Financial Studies}, 21(4), 1509--1531.

\bibitem[Diebold \& Mariano(1995)]{diebold1995}
Diebold, F.~X., \& Mariano, R.~S. (1995). Comparing predictive accuracy. \textit{Journal of Business \& Economic Statistics}, 13(3), 253--263.

\bibitem[Genet \& Inzirillo(2024)]{genet2024tkan}
Genet, R., \& Inzirillo, H. (2024). TKAN: Temporal Kolmogorov-Arnold Networks. \textit{arXiv preprint arXiv:2405.07344}.

\bibitem[Granger(1969)]{granger1969}
Granger, C.~W.~J. (1969). Investigating causal relations by econometric models and cross-spectral methods. \textit{Econometrica}, 37(3), 424--438.

\bibitem[Harvey et al.(1997)]{harvey1997}
Harvey, D., Leybourne, S., \& Newbold, P. (1997). Testing the equality of prediction mean squared errors. \textit{International Journal of Forecasting}, 13(2), 281--291.

\newpage
\bibitem[Kolmogorov(1957)]{kolmogorov1957}
Kolmogorov, A.~N. (1957). On the representation of continuous functions of many variables by superposition of continuous functions of one variable and addition. \textit{Doklady Akademii Nauk SSSR}, 114(5), 953--956.

\bibitem[Liu et al.(2024)]{liu2024itransformer}
Liu, Y., Hu, T., Zhang, H., Wu, H., Wang, S., Ma, L., \& Long, M. (2024). iTransformer: Inverted Transformers Are Effective for Time Series Forecasting. \textit{International Conference on Learning Representations (ICLR)}.

\bibitem[Liu et al.(2025)]{liu2024kan}
Liu, Z., Wang, Y., Vaidya, S., Ruehle, F., Halverson, J., Solja{\v{c}}i{\'c}, M., Hou, T.~Y., \& Tegmark, M. (2025). KAN: Kolmogorov--Arnold Networks. \textit{International Conference on Learning Representations (ICLR)}.

\bibitem[Runge(2020)]{runge2020}
Runge, J. (2020). Discovering contemporaneous and lagged causal relations in autocorrelated nonlinear time series datasets. \textit{Proceedings of the 36th Conference on Uncertainty in Artificial Intelligence (UAI)}, pp.~1388--1397.

\bibitem[Welch \& Goyal(2008)]{welch2008}
Welch, I., \& Goyal, A. (2008). A comprehensive look at the empirical performance of equity premium prediction. \textit{The Review of Financial Studies}, 21(4), 1455--1508.
\end{thebibliography}

\end{document}
"""

with open('paper_manuscript.tex', 'w', encoding='utf-8') as f:
    f.write(tex_code)
print('Wrote paper_manuscript.tex successfully!')
